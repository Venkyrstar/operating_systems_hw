#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <assert.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <errno.h>

#define max 10

struct ioredir {
	char *type;
	char *cmdargs[max][max];
	char *ipfile;
	char *opfile;
	int ipfid;
	int opfid;
};

/**
 ** @brief Launch a program and wait for it to terminate.
 ** @param args Null terminated list of arguments (including program).
 ** @return Always returns 1, to continue execution.
 */
int sh_launch(struct ioredir *redir){
    /* most of your code here */
	
	int fd1;
	int fd2;
	int pipeflag = 0;
	int fd[2];
	int i=0;
	int inp = -1;
	
	if (redir->cmdargs[1][0] != NULL) {
		pipeflag = 1;
	}
	
	while ((redir->cmdargs[i+1][0] != NULL) && (pipeflag == 1)) {
		
		/* if (redir->cmdargs[i+1][0] != NULL) { */
			if(pipe(fd) < 0) {
				printf("238p$ : error while executing pipe command\n");
			}
		/* } */

		int pid1 = fork();
		/* printf("pid %d\n", pid1); */
		
		if (pid1 > 0) {
			/* printf("Parent called\n"); */
			wait(NULL);
		}
		else if (pid1 == 0){
			/* printf("Child called\n");
			printf("pid %d\n", pid1);
			printf("inp %d\n", inp); */
			if ((redir->ipfile != NULL) && ((i) == redir->ipfid)) {
				close(0);
				fd1 = open(redir->ipfile,O_RDONLY);
				if (fd1 < 0) { 
					printf("Error occured while opening the read file\n");
				}
			}
			if ((redir->opfile != NULL) && ((i) == redir->opfid)) {
				close(1);
				fd2 = open(redir->opfile,O_RDWR | O_CREAT, 0644);
				if (fd2 < 0) { 
					printf("Error occured while opening the write file\n");
				}
			}
			
			if (inp == -1) {
				//printf("1st time came here to write to %d\n", out);
				close(1);
				dup(fd[1]);
				close(fd[0]);
				//close(fd[1]);
			} else {
				//printf("came here to read from %d\n",inp);
				close(0);
				dup(inp);
				close(inp);
				/* if (redir->cmdargs[i+1][0] != NULL) {
					close(1);
					dup(fd[1]);
					close(fd[0]);
					close(fd[1]);
				} */
				close(1);
				dup(fd[1]);
				close(fd[0]);
				
			}
			//printf("Coming here to exec \n");
			execvp(redir->cmdargs[i][0],redir->cmdargs[i]);
		}
		close(fd[1]);
		inp = fd[0];
		//printf("inp %d\n", inp);
		i++;
		/* close(fd[0]);
		close(fd[1]); */
		/* wait(NULL);
		wait(NULL); */
		/* int	pid2 = fork();
		printf("pipes pid2 : %d\n", pid2);
		if (pid2 > 0) {
			wait(NULL);
		} else if (pid2 == 0){
			printf("If 2 loop\n");
			if ((redir->ipfile != NULL) && (i == redir->ipfid)) {
				close(0);
				fd1 = open(redir->ipfile,O_RDONLY);
				if (fd1 < 0) { 
					printf("Error occured while opening the read file\n");
				}
			}
			if ((redir->opfile != NULL) && (i == redir->opfid)) {
				close(1);
				fd2 = open(redir->opfile,O_RDWR | O_CREAT, 0644);
				if (fd2 < 0) { 
					printf("Error occured while opening the write file\n");
				}
			}
			close(0);
			dup(stdin);
			close(stdin);
			execvp(redir->cmdargs[i][0],redir->cmdargs[i]);
		} */
	}
	
	if (pipeflag == 1) {
		
		int	pid = fork();

		if (pid > 0) {
			pid = wait(NULL);
		} else if (pid == 0){

			if ((redir->opfile != NULL) && ((i) == redir->opfid)) {
				close(1);
				fd2 = open(redir->opfile,O_RDWR | O_CREAT, 0644);
				if (fd2 < 0) { 
					printf("Error occured while opening the write file\n");
				}
			}
			
			close(0);
			dup(inp);
			close(inp);
	
			execvp(redir->cmdargs[i][0],redir->cmdargs[i]);
		}
	}
	
	if (pipeflag == 0) {
		if (redir->cmdargs[0][0] != NULL) {
			
			if(strcmp(redir->cmdargs[0][0], "cd") == 0){
				  if(chdir(redir->cmdargs[0][1]) != 0) {
					  exit(EXIT_FAILURE);
				  }
				  return 1;
			}

			int	pid = fork();
			/* printf("pid : %d\n", pid); */
			/* printf("TYPE : %s\n", redir->type); */
			if (pid > 0) {
				pid = wait(NULL);
			} else if (pid == 0){
				/* printf("cmd : %s\n", redir->ipfile); */
				if ((redir->ipfile != NULL) && (redir->ipfid == 0)) {
					close(0);
					fd1 = open(redir->ipfile,O_RDONLY);
					if (fd1 < 0) { 
						printf("Error occured while opening the read file\n");
					}
				}
				/* printf("cmd : %s\n", redir->opfile); */
				if ((redir->opfile != NULL) && (redir->opfid == 0)) {
					close(1);
					fd2 = open(redir->opfile,O_RDWR | O_CREAT, 0644);
					if (fd2 < 0) { 
						printf("Error occured while opening the write file\n");
					}
				}
				
				execvp(redir->cmdargs[0][0],redir->cmdargs[0]);
				/* printf("238p$ : error while executing command\n"); */
				/* return 0; */
			} else {
				printf("238p$ : error while fork\n");
				return 0;
			}
		}
	}
	return 1;
}


/**
 ** @brief Execute shell built-in or launch program.
 ** @param args Null terminated list of arguments.
 ** @return 1 if the shell should continue running, 0 if it should terminate
 */
int sh_execute(struct ioredir *redir){
  if (redir->cmdargs[0][0] == NULL) {
    return 1;  // An empty command was entered.
  }
  return sh_launch(redir);   // launch
}


/**
 ** @brief Split a line into tokens (very naively).
 ** @param line The line.
 ** @return Null-terminated array of tokens.
 */
#define SH_TOK_BUFSIZE 64
#define SH_TOK_DELIM " \t\r\n\a"
struct ioredir *sh_split_line(char *line){
    //int bufsize = SH_TOK_BUFSIZE;
    int position = 0;
	int count = 0;
    /* char **tokens = malloc(bufsize * sizeof(char *)); */
    char *token, *prevtoken/* , **tokens_backup */;
	struct ioredir *redir = malloc(sizeof(*redir));
	char *inpr = "<";
	char *outr = ">";
	char *pipe = "|";
	/* printf("Came here 2\n"); */
   /*  if(!tokens){
        fprintf(stderr, "sh238p: allocation error\n");
        exit(EXIT_FAILURE);
    } */

    token = strtok(line, SH_TOK_DELIM);
	
	if (redir->ipfile != NULL) {
		redir->ipfile = NULL;
	}
	
	if (redir->opfile != NULL) {
		redir->opfile = NULL;
	}
	
	/* printf(" %s\n",redir->ipfile);
	printf(" %s\n",redir->opfile); */
    while(token != NULL){
        
		/* printf("Came here 3\n"); */
		/* printf("prevtoken begin %s\n", prevtoken);
		printf("token begin %s\n", token); */
		if (count >= 1) {
			if (strcmp(prevtoken, inpr) == 0) {
				/* printf("Came here 8\n"); */
				redir->ipfile = token;
				redir->ipfid = position;
				/* redir->type = "REDIR"; */
				/* printf(" %s\n",redir->ipfile);
				printf(" %d\n",redir->ipfid); */
			}
			
			if (strcmp(prevtoken, outr) == 0) {
				/* printf("Came here 9\n"); */
				redir->opfile = token;
				redir->opfid = position;
				/* redir->type = "REDIR"; */
				/* printf(" %s\n",redir->opfile);
				printf(" %d\n",redir->opfid); */
			}
		
		}
		
		
		if ((strcmp(token, pipe) != 0) && (strcmp(token, inpr) != 0) && (strcmp(token, outr) != 0) 
			&& (strcmp(prevtoken, inpr) != 0) && (strcmp(prevtoken, outr) != 0)) {
			redir->cmdargs[position][count] = token;
			/* printf(" %s\n",redir->cmdargs[position][count]); */
			count++;
		} else if ((strcmp(token, inpr) == 0) || (strcmp(token, outr) == 0)) {
			/* printf(" Came here ioredir\n",redir->cmdargs[position][count]); */
			redir->cmdargs[position][count] = NULL;
		} else if (strcmp(token, pipe) == 0) {
			/* printf(" Came here pipe\n"); */
			redir->cmdargs[position][count] = NULL;
			position++;
			count = 0;
		}
		
		prevtoken = token;
		/* printf("prevtoken %s\n", prevtoken); */
        /* if(position >= bufsize){
			printf("Came here 10\n");
            bufsize += SH_TOK_BUFSIZE;
            tokens_backup = tokens;
            tokens = realloc(tokens, bufsize * sizeof(char *));
            if(!tokens){
                free(tokens_backup);
                fprintf(stderr, "sh238p: allocation error\n");
                exit(EXIT_FAILURE);
            }
        } */

        token = strtok(NULL, SH_TOK_DELIM);
    }
	/* redir->cmdargs[position][count] = NULL; */
    return redir;
}


/**
 ** @brief Read a line of input from stdin.
 ** @return The line from stdin.
 **/
char *sh_read_line(void){
    char *line = NULL;
    size_t bufsize = 0;  // have getline allocate a buffer for us
    if(getline(&line, &bufsize, stdin) == -1){
        if(feof(stdin)){ // We recieved an EOF
            exit(EXIT_SUCCESS);  
        }else{
            perror("sh238p: sh_read_line");
            exit(EXIT_FAILURE);
        }
    }
    return line;
}


/**
 ** @brief Loop getting input and executing it.
 **/
void sh_loop(void){
    char *line;
	//char temp[256];
    //char **args;
	struct ioredir *redir;
	//struct pipes *pipe;
    int status;
    do{
        printf("238p$ ");
        line = sh_read_line();
        redir = sh_split_line(line);
		status = sh_execute(redir);
        free(line);
        //free(args);
    }while(status);
}


/**
 ** @brief Main entry point.
 ** @param argc Argument count.
 ** @param argv Argument vector.
 ** @return status code
 **/
int main(int argc, char **argv){
    sh_loop();
    return EXIT_SUCCESS;
}
