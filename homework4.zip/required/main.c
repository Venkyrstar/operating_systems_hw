#include "console.h"

extern char end[];
#define PGSIZE 4096
#define PGROUNDUP(sz) (((sz)+PGSIZE-1) & ~(PGSIZE-1))


static inline void lcr3(unsigned int val)
{   
  asm volatile("movl %0,%%cr3" : : "r" (val));
}

static inline void halt(void)
{
    asm volatile("hlt" : : );
}



int main(void)
{
    int i; 
    int sum = 0;

    // Initialize the console
    uartinit(); 

    printk("Hello from C\n");

    // Create your page table here
    unsigned int pgdirst;
	unsigned int ptest;
	int a;
	int b;
	unsigned int temp = 0;
	unsigned int temp1 = 1024 * 4096;

	pgdirst = PGROUNDUP((unsigned int)end);
	ptest = pgdirst + PGSIZE;
	for (a = 0; a <= 1; a++) {
		unsigned int *pgdir = (unsigned int *)(4 * a + pgdirst);
		*pgdir = ptest | 0b11;
		for (b = 0; b < 1024; b++) {
			unsigned int *pte = (unsigned int *)(ptest + b * 4);
			temp = b * PGSIZE + a * temp1;
			temp = temp | 0b00000011;
			*pte = temp;
		}
		ptest = ptest + PGSIZE;
	}
	lcr3(pgdirst);

    for (i = 0; i < /* 32 */ 64 ; i++) {
        int *p = (int *)(i * 4096 * 32);
        sum += *p; 
             
        printk("page\n"); 
    }
    halt(); 
    return sum; 
}



