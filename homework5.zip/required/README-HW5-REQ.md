Steps folowed to create newproc system call
1. Add the details required to create a new system call in the below mentioned files similar to system call uptime
	1. syscall.c
	2. syscall.h
	3. user.h
	4. usys.S
	5. sysproc.c
2. Write a function sys_newproc similar to other system calls. Validate the arguments passed and if error return -1. After validating the arguments, call a function newproc which will defined in file proc.c.
3. Define a function newproc which takes path and argv as arguments. The functionality of newproc should combine functionality of fork and exec system call into one system call.
4. Allocate a new process and set parent, trap frame, open files, current directory of new process same as the current process.
5. Get inode pointer from the path argument. Read the inode pointer using readi and get the ELF data structure details for the file.
6. Validate the ELF file. Setup the page table directory. Load the program into the memory. Setup the user stack and push the arguments passed on to the user stack. Prepare the rest of the user stack.
7. Update the new process page table directory, size of process memory, instruction pointer and stack pointer.
8. Acquire the lock and change the processs state to RUNNABLE. Release the lock.
9. Call wait() to avoid creation of zombie process.
10. Return the process ID. -2 will be returned in case of any other errors incurred suring the execution.
11. Update the Makefile to add entry from newproc-test and place the newproc-test.c file in the path.
12. Run make qemu-nox to boot into xv6. Run the newproc-test in the shell.
13. Output should be displayed for the command arguments passed and new process ID should be printed on console.